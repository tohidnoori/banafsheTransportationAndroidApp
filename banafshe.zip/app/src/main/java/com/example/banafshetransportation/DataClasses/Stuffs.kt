package com.example.banafshetransportation.DataClasses

data class Stuffs(
    val stuffName:String,
    val numStuff:Int,
    val stuffDesc:String
)
