package com.example.banafshetransportation.DataClasses

data class CoWorkersIDs(
    val name:String,
    val phone:Long,
    val job:String
)
