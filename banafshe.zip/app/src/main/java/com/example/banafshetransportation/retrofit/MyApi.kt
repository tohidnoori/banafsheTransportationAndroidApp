package com.example.banafshetransportation.retrofit

import com.example.banafshetransportation.DataClasses.Resids
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.*

interface MyApi {
    @GET("getResids2.php")
    suspend fun getResids(
        @Query("content-type") contentType: String,
    ): Response<MyResponse<ArrayList<Resids>>>
}