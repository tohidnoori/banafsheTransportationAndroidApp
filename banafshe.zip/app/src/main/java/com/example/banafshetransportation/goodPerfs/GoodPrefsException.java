package com.example.banafshetransportation.goodPerfs;

public class GoodPrefsException extends RuntimeException {

    public GoodPrefsException(String message) {
        super(message);
    }
}